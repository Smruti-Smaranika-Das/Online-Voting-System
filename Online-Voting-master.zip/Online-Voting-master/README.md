# Online-Voting
Online Election Voting System developed in Advance Java.
The front end of the Project contains software such as HTML, CSS, Javascript, JSP, JDBC. The back end requires MySQL software to run. IDE IntelliJ IDEA or net beans or my eclipse must be installed. MySQL database is being used. Any IDE can be used for the development of the project, MySQL can be used for databases, and Apache Tomcat as a server.

Software Requirements
•	Xammp(for MySQL dB and tomcat server)
•	JDK
•	IntelliJ IDEA
•	my-SQL connector


The dependencies are managed using maven.
JSTL library 

this project can be directly imported and run after adding all the dependencies
